/* ==========================================================================
   js/storage/storage.js

   PURPOSE
   Persistence layer for the survey. This used to write straight to
   localStorage; it now talks to the FastAPI backend over fetch(), but
   keeps the exact same public method names (getResponseId,
   getAllAnswers, saveResponse, submitCompletedSurvey, clearResponse,
   hasSubmittedResponse) that js/engine/engine.js already calls. That's
   the whole payoff of having a Storage "seam" from the start: the
   backend swap only touches this file.

   WHAT CHANGED, CONCRETELY
   - Every method that used to be synchronous is now async (returns a
     Promise), because a network call replaced a localStorage read/write.
     engine.js awaits these calls.
   - Only the small, non-sensitive `response_id` is kept in localStorage
     — as a "who am I, if I reload this page" pointer — never the actual
     answers. Answers live only on the server.
   - An in-memory cache (`_answersCache`) mirrors the server so
     getAllAnswers() can stay fast and synchronous-feeling for the
     progress bar / rendering code that reads it many times per screen.
   ========================================================================== */

window.SmartMatatu = window.SmartMatatu || {};

window.SmartMatatu.Storage = {
  STORAGE_KEY_RESPONSE_ID: "smartmatatu_response_id",

  _responseId: null,
  _answersCache: {},
  _isSubmitted: false,

  _apiUrl(path) {
    return `${window.SmartMatatu.API_BASE_URL}${path}`;
  },

  /**
   * Must be called once before anything else (engine.js does this at
   * survey start). Figures out who this respondent is — reusing a
   * response_id already saved in this browser (so a page refresh mid
   * survey resumes instead of starting over), or asking the backend to
   * create a brand new one — then pulls down whatever answers already
   * exist for it.
   * @returns {Promise<object>} the respondent's current answers
   */
  async init() {
    const existingId = localStorage.getItem(this.STORAGE_KEY_RESPONSE_ID);

    if (existingId) {
      try {
        const response = await fetch(this._apiUrl(`/responses/${existingId}`));
        if (response.ok) {
          const data = await response.json();
          if (!data.is_submitted) {
            this._responseId = data.response_id;
            this._answersCache = data.answers || {};
            this._isSubmitted = false;
            return this._answersCache;
          }
          // That id was already submitted (e.g. respondent finished, then
          // came back to the survey URL) — fall through and start fresh.
        }
      } catch (error) {
        console.warn("storage.js: could not resume existing response, starting a new one.", error);
      }
    }

    return this._startNewResponse();
  },

  async _startNewResponse() {
    const response = await fetch(this._apiUrl("/responses"), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({})
    });
    if (!response.ok) {
      throw new Error(`Could not start a new survey response (status ${response.status}).`);
    }
    const data = await response.json();
    this._responseId = data.response_id;
    this._answersCache = {};
    this._isSubmitted = false;
    localStorage.setItem(this.STORAGE_KEY_RESPONSE_ID, this._responseId);
    return this._answersCache;
  },

  getResponseId() {
    return this._responseId;
  },

  /**
   * Synchronous on purpose — reads the in-memory cache kept up to date
   * by init()/saveResponse(), so rendering code (which calls this often)
   * doesn't need to be async just to read an answer.
   */
  getAllAnswers() {
    return this._answersCache;
  },

  /**
   * Saves one answer. Updates the in-memory cache immediately, then
   * persists it to the backend. Throws if the network request fails, so
   * the caller (engine.js) can show an error instead of silently losing
   * an answer.
   */
  async saveResponse(questionId, answer) {
    this._answersCache = { ...this._answersCache, [questionId]: answer };

    const response = await fetch(this._apiUrl(`/responses/${this._responseId}`), {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ answers: { [questionId]: answer } })
    });

    if (!response.ok) {
      throw new Error(`Could not save your answer (status ${response.status}). Please check your connection.`);
    }
  },

  async submitCompletedSurvey() {
    const response = await fetch(this._apiUrl(`/responses/${this._responseId}/submit`), {
      method: "POST"
    });
    if (!response.ok) {
      throw new Error(`Could not submit the survey (status ${response.status}). Please try again.`);
    }
    this._isSubmitted = true;
    const data = await response.json();
    return { responseId: data.response_id, answers: data.answers, submittedAt: data.submitted_at };
  },

  /**
   * Forgets the locally cached response_id, so the NEXT survey visit
   * starts a brand new response instead of resuming this one. Does not
   * delete anything server-side.
   */
  clearResponse() {
    localStorage.removeItem(this.STORAGE_KEY_RESPONSE_ID);
    this._responseId = null;
    this._answersCache = {};
    this._isSubmitted = false;
  },

  hasSubmittedResponse() {
    return this._isSubmitted;
  }
};
