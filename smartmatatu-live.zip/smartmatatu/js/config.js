/* ==========================================================================
   js/config.js

   PURPOSE
   The one place both the public survey and the admin dashboard read the
   backend's URL from. Change API_BASE_URL here when you deploy the
   backend somewhere other than your own machine (e.g. a real domain) —
   nothing else in either app needs to change.
   ========================================================================== */

window.SmartMatatu = window.SmartMatatu || {};

window.SmartMatatu.API_BASE_URL = "http://127.0.0.1:8000/api";
