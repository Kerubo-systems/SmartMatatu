/* ==========================================================================
   js/app.js

   PURPOSE
   The page-level glue script, loaded last on every public page. Handles
   whatever is specific to the page it's running on: starting the survey
   engine on survey.html, wiring the "Begin survey" button on index.html,
   and showing the response id on thank-you.html — plus the light/dark
   theme toggle shared by all three pages.

   NOTE: this file was referenced by index.html / survey.html /
   thank-you.html but wasn't part of the original file set — it's
   created here as part of wiring the survey up to the real backend, so
   there's actually something calling Engine.startSurvey().
   ========================================================================== */

(function () {
  const THEME_STORAGE_KEY = "smartmatatu_theme";

  function applyTheme(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    const label = document.getElementById("theme-toggle-label");
    if (label) label.textContent = theme === "dark" ? "Light mode" : "Dark mode";
    localStorage.setItem(THEME_STORAGE_KEY, theme);
  }

  function initThemeToggle() {
    const toggleBtn = document.getElementById("theme-toggle-btn");
    applyTheme(localStorage.getItem(THEME_STORAGE_KEY) || "light");
    toggleBtn?.addEventListener("click", () => {
      const current = document.documentElement.getAttribute("data-theme");
      applyTheme(current === "dark" ? "light" : "dark");
    });
  }

  function initHomePage() {
    const beginButton = document.getElementById("begin-survey-btn");
    beginButton?.addEventListener("click", () => {
      window.location.href = "survey.html";
    });
  }

  function initSurveyPage() {
    const container = document.getElementById("question-container");
    if (!container) return;
    window.SmartMatatu.Engine.startSurvey(container);
  }

  function initThankYouPage() {
    const display = document.getElementById("response-id-display");
    if (!display) return;
    const responseId = localStorage.getItem(window.SmartMatatu.Storage.STORAGE_KEY_RESPONSE_ID);
    display.textContent = responseId || "Unavailable";
  }

  document.addEventListener("DOMContentLoaded", () => {
    initThemeToggle();
    initHomePage();
    initSurveyPage();
    initThankYouPage();
  });
})();
