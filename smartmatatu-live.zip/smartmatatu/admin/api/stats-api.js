/* ==========================================================================
   admin/api/stats-api.js

   PURPOSE
   Aggregation (averages, distributions, ranking summaries) for the
   dashboard, read straight from the backend's /api/stats/* endpoints —
   where app/services/stats_service.py does the actual math against the
   real database. No local computation or mock fallback here; if the
   backend is unreachable, these throw and the calling dashboard/*.js
   view shows an error state instead of a number.
   ========================================================================== */

window.AdminAPI = window.AdminAPI || {};

window.AdminAPI.Stats = {
  /**
   * Headline numbers for the stat cards on the Home page.
   * Backed by GET /api/stats/summary.
   */
  async getSummary() {
    const data = await window.AdminAPI.Client.getJSON("/stats/summary");
    return {
      totalResponses: data.total_responses,
      averageSafety: { average: data.average_safety.average, maxScore: data.average_safety.max_score, sampleSize: data.average_safety.sample_size },
      averageComfort: { average: data.average_comfort.average, maxScore: data.average_comfort.max_score, sampleSize: data.average_comfort.sample_size },
      averageFareFairness: { average: data.average_fare_fairness.average, maxScore: data.average_fare_fairness.max_score, sampleSize: data.average_fare_fairness.sample_size },
      futureParticipationRate: data.future_participation_rate
    };
  },

  /**
   * Chart-ready distributions for every categorical question on Home.
   * Backed by GET /api/stats/distributions.
   */
  async getDistributions() {
    const data = await window.AdminAPI.Client.getJSON("/stats/distributions");
    return {
      age: data.age,
      frequency: data.frequency,
      safety: data.safety,
      comfort: data.comfort,
      fareFairness: data.fare_fairness,
      priorityFeature: data.priority_feature
    };
  },

  /**
   * Ranks the 7 frustration-ranking options by average rank position.
   * Backed by GET /api/stats/ranking.
   */
  async getFrustrationRanking() {
    const data = await window.AdminAPI.Client.getJSON("/stats/ranking");
    return data.map((r) => ({ value: r.value, label: r.label, averageRank: r.average_rank }));
  }
};
