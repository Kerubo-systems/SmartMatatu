/* ==========================================================================
   admin/api/api-client.js

   PURPOSE
   One shared fetch() wrapper for every admin/api/*.js file, plus a small
   piece of shared state (`window.AdminAPI.backendStatus`) so the UI can
   show a banner when the real backend isn't reachable and the dashboard
   has quietly fallen back to the old mock dataset. Falling back — rather
   than just showing an error — means the dashboard is still fully
   demoable (e.g. in a preview with no network access to localhost)
   even without the FastAPI server running.
   ========================================================================== */

window.AdminAPI = window.AdminAPI || {};

window.AdminAPI.backendStatus = {
  reachable: null, // null = not checked yet, true/false after the first request
  lastCheckedAt: null,
  lastError: null
};

window.AdminAPI.Client = {
  baseUrl() {
    return window.SmartMatatu.API_BASE_URL;
  },

  _recordSuccess() {
    window.AdminAPI.backendStatus = { reachable: true, lastCheckedAt: new Date(), lastError: null };
  },

  _recordFailure(error) {
    window.AdminAPI.backendStatus = { reachable: false, lastCheckedAt: new Date(), lastError: error.message };
  },

  /**
   * GETs a JSON endpoint. Throws on any network error or non-2xx status,
   * so callers can catch it and fall back to mock data.
   */
  async getJSON(path) {
    try {
      const response = await fetch(`${this.baseUrl()}${path}`);
      if (!response.ok) throw new Error(`Backend returned status ${response.status} for ${path}`);
      const data = await response.json();
      this._recordSuccess();
      return data;
    } catch (error) {
      this._recordFailure(error);
      throw error;
    }
  },

  /** Fetches a file (CSV/JSON export) and triggers a browser download. */
  async downloadFile(path, filename) {
    const response = await fetch(`${this.baseUrl()}${path}`);
    if (!response.ok) throw new Error(`Backend returned status ${response.status} for ${path}`);
    this._recordSuccess();

    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
};
