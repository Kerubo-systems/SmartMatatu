/* ==========================================================================
   admin/api/export-api.js

   PURPOSE
   Triggers CSV/JSON downloads straight from the backend's own export
   endpoints (GET /api/export/csv, /json), which build the file from the
   real database. No client-side/mock fallback — if the backend can't be
   reached, this throws and the Export button's click handler
   (admin/js/app.js) shows an error instead of downloading anything.
   ========================================================================== */

window.AdminAPI = window.AdminAPI || {};

window.AdminAPI.Export = {
  /** Downloads a CSV of every submitted response. */
  async exportCSV() {
    const dateStamp = new Date().toISOString().slice(0, 10);
    await window.AdminAPI.Client.downloadFile("/export/csv", `smartmatatu-responses-${dateStamp}.csv`);
  },

  /** Downloads a JSON file of every submitted response. */
  async exportJSON() {
    const dateStamp = new Date().toISOString().slice(0, 10);
    await window.AdminAPI.Client.downloadFile("/export/json", `smartmatatu-responses-${dateStamp}.json`);
  }
};
