/* ==========================================================================
   admin/api/responses-api.js

   PURPOSE
   Reads survey responses from the real backend only. There is no mock
   data / offline fallback here on purpose — this dashboard is for real
   research data, so if the backend can't be reached, callers should see
   that clearly (an error) rather than a dashboard full of numbers that
   look real but aren't. See admin/js/app.js for how sections display
   that error state.
   ========================================================================== */

window.AdminAPI = window.AdminAPI || {};

window.AdminAPI.Responses = {
  // Maps the backend's snake_case response shape onto the shape the
  // dashboard's view code expects.
  _mapBackendResponse(r) {
    return { responseId: r.response_id, submittedAt: r.submitted_at, answers: r.answers };
  },

  /**
   * Returns every submitted response.
   * @returns {Promise<Array<{responseId: string, submittedAt: string, answers: object}>>}
   */
  async getAll() {
    const data = await window.AdminAPI.Client.getJSON("/responses?submitted_only=true");
    return data.map(this._mapBackendResponse);
  },

  /**
   * Returns just the count of responses.
   * @returns {Promise<number>}
   */
  async getCount() {
    const data = await window.AdminAPI.Client.getJSON("/responses/count?submitted_only=true");
    return data.count;
  },

  /**
   * Returns every recorded answer for a single question id, paired with
   * the response it came from. Used by the open-ended responses table.
   * @param {string} questionId
   * @returns {Promise<Array<{responseId: string, submittedAt: string, answer: string}>>}
   */
  async getAnswersForQuestion(questionId) {
    const all = await this.getAll();
    return all
      .filter((r) => r.answers[questionId] !== undefined && r.answers[questionId] !== null)
      .map((r) => ({
        responseId: r.responseId,
        submittedAt: r.submittedAt,
        answer: r.answers[questionId]
      }));
  }
};
