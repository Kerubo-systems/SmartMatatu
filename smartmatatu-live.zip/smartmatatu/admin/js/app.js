/* ==========================================================================
   admin/js/app.js

   PURPOSE
   The dashboard's entry point. Handles section navigation, the light/dark
   theme toggle (kept independent from the public survey's own copy), and
   wiring the export buttons. Each nav section is rendered fresh by its
   dashboard/*.js function every time it's opened, which keeps this file
   from needing to know anything about how any section works internally.
   ========================================================================== */

(function () {
  const SECTIONS = {
    home: { render: (el) => window.AdminDashboard.renderHome(el), label: "Home" },
    responses: { render: (el) => window.AdminDashboard.renderResponses(el), label: "Responses" },
    ranking: { render: (el) => window.AdminDashboard.renderRanking(el), label: "Ranking Analysis" },
    "survey-manager": { render: (el) => window.AdminDashboard.renderSurveyManager(el), label: "Survey Manager" },
    settings: { render: (el) => window.AdminDashboard.renderSettings(el), label: "Settings" }
  };

  const contentEl = document.getElementById("dashboard-content");
  const navLinks = document.querySelectorAll(".sidebar-nav__link");

  async function showSection(sectionId) {
    const section = SECTIONS[sectionId];
    if (!section) return;

    navLinks.forEach((link) => {
      const isActive = link.dataset.section === sectionId;
      link.classList.toggle("sidebar-nav__link--active", isActive);
      link.setAttribute("aria-current", isActive ? "page" : "false");
    });

    contentEl.setAttribute("aria-busy", "true");
    await section.render(contentEl);
    contentEl.setAttribute("aria-busy", "false");
    contentEl.focus();
    updateBackendStatusBanner();

    window.location.hash = sectionId;
  }

  // --- Backend status banner -------------------------------------------
  // admin/api/api-client.js records whether the last request it made
  // succeeded or failed. There's no mock-data fallback in this dashboard
  // — if the backend is unreachable, each section shows its own error
  // state (see admin/dashboard/error-state.js), and this banner is a
  // persistent reminder of the same thing across every section.
  function updateBackendStatusBanner() {
    const banner = document.getElementById("backend-status-banner");
    const bannerText = document.getElementById("backend-status-banner-text");
    if (!banner || !bannerText) return;

    const status = window.AdminAPI.backendStatus;
    if (status.reachable === false) {
      bannerText.textContent = `Can't reach the backend at ${window.SmartMatatu.API_BASE_URL}. No data is available until it's running.`;
      banner.hidden = false;
    } else {
      banner.hidden = true;
    }
  }

  navLinks.forEach((link) => {
    link.addEventListener("click", (event) => {
      event.preventDefault();
      showSection(link.dataset.section);
      closeMobileNavIfOpen();
    });
  });

  // --- Theme toggle (mirrors the public site's light/dark tokens) --------
  const THEME_STORAGE_KEY = "smartmatatu_admin_theme";
  const themeToggleBtn = document.getElementById("theme-toggle-btn");
  const themeToggleLabel = document.getElementById("theme-toggle-label");

  function applyTheme(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    if (themeToggleLabel) themeToggleLabel.textContent = theme === "dark" ? "Light mode" : "Dark mode";
    localStorage.setItem(THEME_STORAGE_KEY, theme);
  }

  themeToggleBtn?.addEventListener("click", () => {
    const current = document.documentElement.getAttribute("data-theme");
    applyTheme(current === "dark" ? "light" : "dark");
    // Charts read colors from CSS variables at render time, so the
    // currently visible section needs a re-render to pick up the new theme.
    const activeLink = document.querySelector(".sidebar-nav__link--active");
    if (activeLink) showSection(activeLink.dataset.section);
  });

  applyTheme(localStorage.getItem(THEME_STORAGE_KEY) || "light");

  // --- Mobile nav toggle ---------------------------------------------------
  const mobileNavToggle = document.getElementById("mobile-nav-toggle");
  const sidebar = document.getElementById("sidebar");

  mobileNavToggle?.addEventListener("click", () => {
    sidebar.classList.toggle("sidebar--open");
    const isOpen = sidebar.classList.contains("sidebar--open");
    mobileNavToggle.setAttribute("aria-expanded", String(isOpen));
  });

  function closeMobileNavIfOpen() {
    sidebar?.classList.remove("sidebar--open");
    mobileNavToggle?.setAttribute("aria-expanded", "false");
  }

  // --- Export buttons -------------------------------------------------------
  document.getElementById("export-csv-btn")?.addEventListener("click", async (event) => {
    await withButtonLoadingState(event.currentTarget, () => window.AdminAPI.Export.exportCSV());
  });

  document.getElementById("export-json-btn")?.addEventListener("click", async (event) => {
    await withButtonLoadingState(event.currentTarget, () => window.AdminAPI.Export.exportJSON());
  });

  async function withButtonLoadingState(button, action) {
    const originalText = button.textContent;
    button.disabled = true;
    button.textContent = "Preparing…";
    try {
      await action();
    } catch (error) {
      console.error(error);
      alert(`Couldn't export — can't reach the backend at ${window.SmartMatatu.API_BASE_URL}.`);
    } finally {
      button.disabled = false;
      button.textContent = originalText;
    }
  }

  // --- Initial section (supports deep-linking via #hash) --------------------
  const initialSection = window.location.hash.replace("#", "");
  showSection(SECTIONS[initialSection] ? initialSection : "home");
})();
