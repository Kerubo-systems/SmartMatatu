/* ==========================================================================
   admin/dashboard/responses.js

   PURPOSE
   Renders a searchable, filterable table of open-ended (free text)
   answers: Question / Response / Date. Filtering happens against data
   already fetched via api/responses-api.js — this file never reaches
   into storage/ directly.
   ========================================================================== */

window.AdminDashboard = window.AdminDashboard || {};

window.AdminDashboard.renderResponses = async function (container) {
  const openEndedQuestions = window.SmartMatatu.QUESTIONS.filter((q) => q.type === "open-ended");

  container.innerHTML = `
    <header class="view-header">
      <h1>Open-ended Responses</h1>
      <p class="view-subtitle">Search and filter free-text answers across the survey</p>
    </header>

    <div class="table-controls">
      <label class="field">
        <span class="field__label">Filter by question</span>
        <select id="question-filter" class="text-input">
          <option value="all">All questions</option>
          ${openEndedQuestions.map((q) => `<option value="${q.id}">${q.text}</option>`).join("")}
        </select>
      </label>
      <label class="field field--grow">
        <span class="field__label">Search</span>
        <input type="search" id="response-search" class="text-input" placeholder="Search response text..." />
      </label>
    </div>

    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr><th>Question</th><th>Response</th><th>Date</th></tr>
        </thead>
        <tbody id="responses-table-body">
          <tr><td colspan="3" class="data-table__empty">Loading responses&hellip;</td></tr>
        </tbody>
      </table>
    </div>
  `;

  // Pull every open-ended answer up front; filtering afterwards is just
  // array work, no repeated API calls needed.
  let allRows;
  try {
    allRows = (
      await Promise.all(
        openEndedQuestions.map(async (q) => {
          const answers = await window.AdminAPI.Responses.getAnswersForQuestion(q.id);
          return answers.map((a) => ({
            questionId: q.id,
            questionText: q.text,
            response: a.answer,
            date: a.submittedAt
          }));
        })
      )
    ).flat();
  } catch (error) {
    window.AdminDashboard.renderErrorState(container, error, () => window.AdminDashboard.renderResponses(container));
    return;
  }

  allRows.sort((a, b) => new Date(b.date) - new Date(a.date));

  const questionFilter = document.getElementById("question-filter");
  const searchInput = document.getElementById("response-search");
  const tableBody = document.getElementById("responses-table-body");

  function renderRows() {
    const selectedQuestion = questionFilter.value;
    const searchTerm = searchInput.value.trim().toLowerCase();

    const filtered = allRows.filter((row) => {
      const matchesQuestion = selectedQuestion === "all" || row.questionId === selectedQuestion;
      const matchesSearch = !searchTerm || row.response.toLowerCase().includes(searchTerm);
      return matchesQuestion && matchesSearch && row.response.trim() !== "";
    });

    if (filtered.length === 0) {
      tableBody.innerHTML = `<tr><td colspan="3" class="data-table__empty">No responses match your filters.</td></tr>`;
      return;
    }

    tableBody.innerHTML = filtered
      .map(
        (row) => `
          <tr>
            <td>${escapeHtml(row.questionText)}</td>
            <td>${escapeHtml(row.response)}</td>
            <td>${formatDate(row.date)}</td>
          </tr>
        `
      )
      .join("");
  }

  questionFilter.addEventListener("change", renderRows);
  searchInput.addEventListener("input", renderRows);
  renderRows();
};

function formatDate(isoString) {
  const date = new Date(isoString);
  return date.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

function escapeHtml(value) {
  const div = document.createElement("div");
  div.textContent = value;
  return div.innerHTML;
}
