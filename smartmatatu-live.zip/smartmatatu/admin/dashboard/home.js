/* ==========================================================================
   admin/dashboard/home.js

   PURPOSE
   Renders the Home section: headline stat cards plus the six distribution
   charts. This file only asks api/ for numbers and hands them to charts/ —
   it never touches raw response data itself.
   ========================================================================== */

window.AdminDashboard = window.AdminDashboard || {};

window.AdminDashboard.renderHome = async function (container) {
  container.innerHTML = `
    <header class="home-banner">
      <div class="home-banner__text">
        <h1>SmartMatatu Research Dashboard</h1>
        <p class="view-subtitle">Passenger Experience Study 2026</p>
      </div>
    </header>

    <section class="stat-card-grid" id="stat-card-grid" aria-label="Key statistics">
      ${renderStatCardSkeleton("Total Responses", "total-responses", "&#128203;", "total")}
      ${renderStatCardSkeleton("Average Safety Rating", "avg-safety", "&#128737;&#65039;", "safety")}
      ${renderStatCardSkeleton("Average Comfort Rating", "avg-comfort", "&#128717;&#65039;", "comfort")}
      ${renderStatCardSkeleton("Average Fare Fairness", "avg-fare", "&#128176;", "fare")}
      ${renderStatCardSkeleton("Future Participation Rate", "avg-participation", "&#128257;", "participation")}
    </section>

    <section class="chart-grid" aria-label="Response distributions">
      ${chartCard("age-chart", "Age Distribution", "total")}
      ${chartCard("frequency-chart", "Frequency of Matatu Usage", "participation")}
      ${chartCard("safety-chart", "Safety Perception", "safety")}
      ${chartCard("comfort-chart", "Comfort Ratings", "comfort")}
      ${chartCard("fare-chart", "Fare Fairness", "fare")}
      ${chartCard("feature-chart", "Most Desired SmartMatatu Feature", "feature")}
    </section>
  `;

  try {
    const [summary, distribution] = await Promise.all([
      window.AdminAPI.Stats.getSummary(),
      window.AdminAPI.Stats.getDistributions()
    ]);

    fillStatCard("total-responses", summary.totalResponses);
    fillStatCard("avg-safety", formatScore(summary.averageSafety));
    fillStatCard("avg-comfort", formatScore(summary.averageComfort));
    fillStatCard("avg-fare", formatScore(summary.averageFareFairness));
    fillStatCard(
      "avg-participation",
      summary.futureParticipationRate === null ? "—" : `${summary.futureParticipationRate}%`
    );

    const utils = window.AdminCharts;
    utils.renderAgeDistribution(document.getElementById("age-chart"), distribution);
    utils.renderFrequencyChart(document.getElementById("frequency-chart"), distribution);
    utils.renderSafetyChart(document.getElementById("safety-chart"), distribution);
    utils.renderComfortChart(document.getElementById("comfort-chart"), distribution);
    utils.renderFareChart(document.getElementById("fare-chart"), distribution);
    utils.renderFeatureChart(document.getElementById("feature-chart"), distribution);
  } catch (error) {
    window.AdminDashboard.renderErrorState(container, error, () => window.AdminDashboard.renderHome(container));
  }
};

function renderStatCardSkeleton(label, id, icon, accent) {
  return `
    <div class="stat-card stat-card--${accent}">
      <span class="stat-card__icon" aria-hidden="true">${icon}</span>
      <span class="stat-card__label">${label}</span>
      <span class="stat-card__value" id="${id}">&hellip;</span>
    </div>
  `;
}

function fillStatCard(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

function formatScore(score) {
  if (!score || score.average === null) return "—";
  return `${score.average} / ${score.maxScore}`;
}

function chartCard(canvasId, title, accent) {
  return `
    <div class="chart-card chart-card--${accent}">
      <h3 class="chart-card__title">${title}</h3>
      <div class="chart-card__canvas-wrap">
        <canvas id="${canvasId}" role="img" aria-label="${title} chart"></canvas>
      </div>
    </div>
  `;
}
