/* ==========================================================================
   admin/dashboard/settings.js

   PURPOSE
   Displays project-level status, including a REAL, live check of whether
   the backend is reachable and how many responses are actually in the
   database — not hardcoded text. This is the one section that should
   never lie about connection status, since it's where you'd look to
   confirm data collection is actually working.
   ========================================================================== */

window.AdminDashboard = window.AdminDashboard || {};

window.AdminDashboard.renderSettings = async function (container) {
  container.innerHTML = `
    <header class="view-header">
      <h1>Settings</h1>
      <p class="view-subtitle">Project and system status</p>
    </header>

    <dl class="settings-list">
      ${settingsRow("Project Name", "SmartMatatu Research Platform")}
      ${settingsRow("Current Survey", "Passenger Experience Study 2026")}
      ${settingsRow("Survey Status", "Live", "status-pill status-pill--active")}
      ${settingsRow("Backend URL", window.SmartMatatu.API_BASE_URL)}
      <div class="settings-list__row" id="backend-status-row">
        <dt>Backend Status</dt>
        <dd id="backend-status-value">Checking&hellip;</dd>
      </div>
      <div class="settings-list__row" id="total-responses-row">
        <dt>Total Submitted Responses</dt>
        <dd id="total-responses-value">&hellip;</dd>
      </div>
    </dl>

    <p class="settings-note">
      This checks the backend live, every time you open this page — it's
      not a cached or hardcoded value.
    </p>
  `;

  const statusValue = document.getElementById("backend-status-value");
  const countValue = document.getElementById("total-responses-value");

  try {
    const count = await window.AdminAPI.Responses.getCount();
    statusValue.innerHTML = `<span class="status-pill status-pill--active">Connected</span>`;
    countValue.textContent = String(count);
  } catch (error) {
    console.error(error);
    statusValue.innerHTML = `<span class="status-pill status-pill--offline">Unreachable</span>`;
    countValue.textContent = "—";
  }
};

function settingsRow(label, value, valueClass) {
  return `
    <div class="settings-list__row">
      <dt>${label}</dt>
      <dd class="${valueClass || ""}">${value}</dd>
    </div>
  `;
}
