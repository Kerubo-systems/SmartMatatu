/* ==========================================================================
   admin/dashboard/ranking.js

   PURPOSE
   Renders the Ranking Analysis section: a horizontal bar chart plus an
   ordered list, both driven by the same pre-computed averages from
   api/stats-api.js#getFrustrationRanking.
   ========================================================================== */

window.AdminDashboard = window.AdminDashboard || {};

window.AdminDashboard.renderRanking = async function (container) {
  container.innerHTML = `
    <header class="view-header">
      <h1>Ranking Analysis</h1>
      <p class="view-subtitle">Which frustrations respondents rank highest, on average</p>
    </header>

    <div class="chart-card chart-card--wide chart-card--safety">
      <h3 class="chart-card__title">Average frustration rank (1 = most frustrating)</h3>
      <div class="chart-card__canvas-wrap chart-card__canvas-wrap--tall">
        <canvas id="ranking-chart" role="img" aria-label="Frustration ranking chart"></canvas>
      </div>
    </div>

    <ol class="ranking-results" id="ranking-results" aria-label="Frustrations ranked most to least frustrating"></ol>
  `;

  let results;
  try {
    results = await window.AdminAPI.Stats.getFrustrationRanking();
  } catch (error) {
    window.AdminDashboard.renderErrorState(container, error, () => window.AdminDashboard.renderRanking(container));
    return;
  }

  window.AdminCharts.renderRankingChart(document.getElementById("ranking-chart"), results);

  const list = document.getElementById("ranking-results");
  list.innerHTML = results
    .map(
      (r, index) => `
        <li class="ranking-results__item">
          <span class="ranking-results__position">${index + 1}</span>
          <span class="ranking-results__label">${r.label}</span>
          <span class="ranking-results__score">avg rank ${r.averageRank ?? "—"}</span>
        </li>
      `
    )
    .join("");
};
