/* ==========================================================================
   admin/dashboard/error-state.js

   PURPOSE
   One shared "couldn't load real data" view, used by every section in
   dashboard/*.js. There's no mock-data fallback in this dashboard
   anymore — if the backend can't be reached, the person looking at this
   should see a clear error and a retry button, never a screen full of
   numbers that quietly aren't real.
   ========================================================================== */

window.AdminDashboard = window.AdminDashboard || {};

window.AdminDashboard.renderErrorState = function (container, error, onRetry) {
  console.error(error);
  container.innerHTML = `
    <div class="error-state">
      <span class="error-state__icon" aria-hidden="true">&#9888;&#65039;</span>
      <h2>Couldn't load data from the backend</h2>
      <p class="error-state__detail">
        ${window.SmartMatatu.API_BASE_URL} isn't responding. Make sure the
        FastAPI server is running, then try again.
      </p>
      <button type="button" class="btn btn--secondary" id="error-state-retry">Retry</button>
    </div>
  `;
  document.getElementById("error-state-retry")?.addEventListener("click", onRetry);
};
