/* ==========================================================================
   admin/dashboard/survey-manager.js

   PURPOSE
   Version 1 placeholder for managing multiple survey types. No creation
   logic exists yet — this just lays out the cards so the layout doesn't
   need to be redesigned when "New survey" actually does something.
   ========================================================================== */

window.AdminDashboard = window.AdminDashboard || {};

window.AdminDashboard.renderSurveyManager = function (container) {
  const surveys = [
    {
      name: "Passenger Survey",
      description: "The live study collecting passenger experience data.",
      status: "active"
    },
    {
      name: "Driver Survey",
      description: "Understand challenges from the driver's side of the windscreen.",
      status: "planned"
    },
    {
      name: "Prototype Testing Survey",
      description: "Structured feedback once a physical or software prototype exists.",
      status: "planned"
    },
    {
      name: "Accessibility Survey",
      description: "Focused on riders with mobility, visual, or hearing needs.",
      status: "planned"
    }
  ];

  container.innerHTML = `
    <header class="view-header">
      <h1>Survey Manager</h1>
      <p class="view-subtitle">Future surveys will be created and managed from here</p>
    </header>

    <div class="survey-card-grid">
      ${surveys.map(renderSurveyCard).join("")}
    </div>
  `;
};

function renderSurveyCard(survey) {
  const isActive = survey.status === "active";
  return `
    <div class="survey-manager-card">
      <div class="survey-manager-card__top">
        <h3>${survey.name}</h3>
        <span class="status-pill status-pill--${isActive ? "active" : "planned"}">
          ${isActive ? "Active" : "Coming soon"}
        </span>
      </div>
      <p class="survey-manager-card__description">${survey.description}</p>
      <button type="button" class="btn btn--secondary" disabled title="Survey creation isn't built yet">
        ${isActive ? "Manage survey" : "Create survey"}
      </button>
    </div>
  `;
}
