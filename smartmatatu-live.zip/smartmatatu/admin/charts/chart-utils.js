/* ==========================================================================
   admin/charts/chart-utils.js

   PURPOSE
   Small shared helpers used by every chart file. Isolating Chart.js-
   specific setup here (colors, default options, instance bookkeeping)
   means the individual chart files stay short and only describe WHAT to
   draw, not HOW Chart.js needs to be configured.
   ========================================================================== */

window.AdminCharts = window.AdminCharts || {};

window.AdminCharts.utils = {
  // Reads a design token straight from the page so charts automatically
  // match light/dark theme without their own color logic.
  cssVar(name) {
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  },

  palette() {
    return {
      primary: this.cssVar("--color-primary"),
      primaryLight: this.cssVar("--color-primary-light"),
      accent: this.cssVar("--color-accent"),
      track: this.cssVar("--color-track-bg"),
      textSecondary: this.cssVar("--color-text-secondary"),
      textPrimary: this.cssVar("--color-text-primary"),
      border: this.cssVar("--color-border")
    };
  },

  // A short, brand-derived sequence for charts with several categories.
  // Built by stepping opacity/lightness off the two brand hues rather than
  // reaching for a generic rainbow palette.
  categorySequence(count) {
    const p = this.palette();
    const base = [p.primary, p.accent, p.primaryLight, "#8a8a6f", "#c9a15a", "#4f6a58", "#a3714f"];
    return base.slice(0, count);
  },

  baseFont() {
    return { family: getComputedStyle(document.body).fontFamily, size: 12 };
  },

  // Destroys a previous Chart.js instance on a canvas before redrawing,
  // so re-rendering a section (e.g. after a theme toggle) doesn't leak
  // chart instances or stack tooltips.
  destroyIfExists(canvas) {
    const existing = Chart.getChart(canvas);
    if (existing) existing.destroy();
  },

  sharedGridOptions() {
    const p = this.palette();
    return {
      grid: { color: p.border },
      ticks: { color: p.textSecondary, font: this.baseFont() }
    };
  },

  /**
   * Draws a simple vertical bar chart for a categorical distribution
   * (labels + values of equal length). Shared by every "distribution"
   * chart on the Home page so each chart file only has to say which
   * question it's charting.
   */
  renderCategoryBar(canvas, { labels, values }) {
    this.destroyIfExists(canvas);
    const grid = this.sharedGridOptions();

    return new Chart(canvas, {
      type: "bar",
      data: {
        labels,
        datasets: [{
          data: values,
          backgroundColor: this.categorySequence(labels.length),
          borderRadius: 6,
          maxBarThickness: 46
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { grid: { display: false }, ticks: grid.ticks },
          y: { beginAtZero: true, ticks: { ...grid.ticks, precision: 0 }, grid: grid.grid }
        }
      }
    });
  },

  /**
   * Draws a horizontal bar chart, used for the frustration ranking summary
   * where reading down a list of labels is clearer than reading across.
   */
  renderHorizontalBar(canvas, { labels, values }, barColor) {
    this.destroyIfExists(canvas);
    const p = this.palette();
    const grid = this.sharedGridOptions();

    return new Chart(canvas, {
      type: "bar",
      data: {
        labels,
        datasets: [{
          data: values,
          backgroundColor: barColor || p.primary,
          borderRadius: 6,
          maxBarThickness: 28
        }]
      },
      options: {
        indexAxis: "y",
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { beginAtZero: true, ticks: grid.ticks, grid: grid.grid },
          y: { grid: { display: false }, ticks: grid.ticks }
        }
      }
    });
  }
};
