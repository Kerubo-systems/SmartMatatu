/* ==========================================================================
   admin/charts/age-distribution.js
   Renders the "age" question as a vertical bar chart.
   ========================================================================== */
window.AdminCharts.renderAgeDistribution = function (canvas, distribution) {
  return window.AdminCharts.utils.renderCategoryBar(canvas, distribution.age);
};
