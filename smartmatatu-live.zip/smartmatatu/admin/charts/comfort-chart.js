/* ==========================================================================
   admin/charts/comfort-chart.js
   Renders the "comfort" rating question.
   ========================================================================== */
window.AdminCharts.renderComfortChart = function (canvas, distribution) {
  return window.AdminCharts.utils.renderCategoryBar(canvas, distribution.comfort);
};
