/* ==========================================================================
   admin/charts/ranking-chart.js
   Renders the frustration-ranking summary (already averaged and sorted
   by admin/api/stats-api.js) as a horizontal bar chart, most frustrating
   at the top.
   ========================================================================== */
window.AdminCharts.renderRankingChart = function (canvas, rankingResults) {
  const labels = rankingResults.map((r) => r.label);
  const values = rankingResults.map((r) => r.averageRank);
  const accent = window.AdminCharts.utils.palette().accent;
  // Lower average rank = more frustrating. Reverse so "most frustrating"
  // reads at the top of the chart, which is how people naturally scan it.
  return window.AdminCharts.utils.renderHorizontalBar(
    canvas,
    { labels: [...labels].reverse(), values: [...values].reverse() },
    accent
  );
};
