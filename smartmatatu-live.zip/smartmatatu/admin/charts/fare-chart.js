/* ==========================================================================
   admin/charts/fare-chart.js
   Renders the "fare-fairness" question.
   ========================================================================== */
window.AdminCharts.renderFareChart = function (canvas, distribution) {
  return window.AdminCharts.utils.renderCategoryBar(canvas, distribution.fareFairness);
};
