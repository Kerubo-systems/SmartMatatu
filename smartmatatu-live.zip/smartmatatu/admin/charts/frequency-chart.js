/* ==========================================================================
   admin/charts/frequency-chart.js
   Renders the "frequency" question (how often respondents use a matatu).
   ========================================================================== */
window.AdminCharts.renderFrequencyChart = function (canvas, distribution) {
  return window.AdminCharts.utils.renderCategoryBar(canvas, distribution.frequency);
};
