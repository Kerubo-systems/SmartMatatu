/* ==========================================================================
   admin/charts/feature-chart.js
   Renders the "priority-feature" question: which SmartMatatu feature
   respondents said would matter most to them.
   ========================================================================== */
window.AdminCharts.renderFeatureChart = function (canvas, distribution) {
  return window.AdminCharts.utils.renderCategoryBar(canvas, distribution.priorityFeature);
};
