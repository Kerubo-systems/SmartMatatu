/* ==========================================================================
   admin/charts/safety-chart.js
   Renders the "safety" perception question.
   ========================================================================== */
window.AdminCharts.renderSafetyChart = function (canvas, distribution) {
  return window.AdminCharts.utils.renderCategoryBar(canvas, distribution.safety);
};
