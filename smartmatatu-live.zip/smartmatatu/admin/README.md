# SmartMatatu Admin Dashboard

Private research dashboard for the SmartMatatu Passenger Experience Study.
Not linked from the public site, not indexed by search engines, and not
protected by a login yet — see "Adding authentication later" below.

Reads real data only, straight from the FastAPI backend in `../backend/`.
There is no mock/demo data built into this dashboard — if the backend is
unreachable, each section shows a clear error and a retry button rather
than any placeholder numbers.

## Running it

1. Start the backend (see `../backend/README.md`).
2. Serve this project's root with any static file server, e.g.
   `python3 -m http.server 5500` from the project root, then visit
   `http://localhost:5500/admin/`.
3. Make sure `../js/config.js`'s `API_BASE_URL` points at your running
   backend.

## How it works

```
admin/api/*.js       →  calls the real backend's REST endpoints
                          (GET /api/stats/*, /api/responses, /api/export/*)
            ↓
admin/charts/*.js     →  Chart.js rendering, driven only by numbers
                          returned from api/
            ↓
admin/dashboard/*.js  →  one file per section (Home, Responses,
                          Ranking, Survey Manager, Settings). Each wraps
                          its api/ calls in try/catch and shows
                          error-state.js's error view on failure.
            ↓
admin/js/app.js       →  navigation, theme toggle, backend-status
                          banner, export buttons
```

## Adding authentication later

`admin/` is already a separate folder with no links in from the public
pages — that's the whole "not for the public" boundary today. When real
authentication is needed, add e.g. `admin/js/auth-guard.js` as the
**first** script tag in `admin/index.html`. It can check for a valid
session and redirect to a login page before anything else runs. No other
file needs to move or change.

**Important if you deploy this publicly**: hosting `admin/index.html` on
the same public static host as the survey (e.g. the same GitHub Pages
site) means it's reachable at a guessable URL, even without a link to
it — that's "no one will stumble onto it," not "no one can access it."
Until real auth exists, the safer option is to keep `admin/` off any
public host and only open it locally (pointed at your live backend via
`API_BASE_URL`) when you want to check on responses.

## Folder structure

| Folder | Purpose |
|---|---|
| `admin/dashboard/` | One view-rendering file per section, plus the shared error-state view. UI only — no data-shaping logic. |
| `admin/charts/` | Chart.js setup, isolated so charting-library details never leak into dashboard files. |
| `admin/api/` | The seam between the UI and the backend. Real data only. |
