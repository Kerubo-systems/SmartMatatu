"""tests/test_responses.py — the survey-facing endpoints."""


def test_start_creates_a_response(client):
    resp = client.post("/api/responses", json={})
    assert resp.status_code == 201
    body = resp.json()
    assert body["response_id"].startswith("SM-")
    assert body["answers"] == {}
    assert body["is_submitted"] is False


def test_save_progress_merges_instead_of_overwriting(client):
    response_id = client.post("/api/responses", json={}).json()["response_id"]

    client.put(f"/api/responses/{response_id}", json={"answers": {"age": "25-34"}})
    second = client.put(f"/api/responses/{response_id}", json={"answers": {"safety": "safe"}})

    assert second.status_code == 200
    assert second.json()["answers"] == {"age": "25-34", "safety": "safe"}


def test_save_progress_creates_response_if_id_unknown(client):
    # Mirrors the frontend's behavior of always PUTting to whatever
    # response_id it currently has cached.
    resp = client.put("/api/responses/SM-2026-BRANDN", json={"answers": {"age": "18-24"}})
    assert resp.status_code == 200
    assert resp.json()["response_id"] == "SM-2026-BRANDN"


def test_submit_marks_submitted_and_sets_timestamp(client):
    response_id = client.post("/api/responses", json={}).json()["response_id"]
    resp = client.post(f"/api/responses/{response_id}/submit")
    assert resp.status_code == 200
    body = resp.json()
    assert body["is_submitted"] is True
    assert body["submitted_at"] is not None


def test_submit_unknown_id_returns_404(client):
    resp = client.post("/api/responses/SM-2026-NOPE01/submit")
    assert resp.status_code == 404


def test_get_unknown_response_returns_404(client):
    resp = client.get("/api/responses/SM-2026-NOPE02")
    assert resp.status_code == 404


def test_list_only_returns_submitted_by_default(client):
    submitted_id = client.post("/api/responses", json={}).json()["response_id"]
    client.post(f"/api/responses/{submitted_id}/submit")

    client.post("/api/responses", json={})  # left unsubmitted

    submitted_only = client.get("/api/responses").json()
    everything = client.get("/api/responses?submitted_only=false").json()

    assert len(submitted_only) == 1
    assert submitted_only[0]["response_id"] == submitted_id
    assert len(everything) == 2


def test_count_matches_list_length(client):
    for _ in range(3):
        rid = client.post("/api/responses", json={}).json()["response_id"]
        client.post(f"/api/responses/{rid}/submit")

    assert client.get("/api/responses/count").json()["count"] == 3


def test_delete_response(client):
    response_id = client.post("/api/responses", json={}).json()["response_id"]
    assert client.delete(f"/api/responses/{response_id}").status_code == 204
    assert client.get(f"/api/responses/{response_id}").status_code == 404
