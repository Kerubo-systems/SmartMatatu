"""
tests/conftest.py

PURPOSE
Gives every test a throwaway in-memory SQLite database, wired in via
FastAPI's dependency override for `get_db` — the app under test never
touches the real `smartmatatu.db` file. This is the standard
FastAPI+SQLAlchemy testing pattern, and it's only this simple because
every query goes through `get_db` / the repository layer; nothing
reaches for a database connection on its own.
"""

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.api.deps import get_db
from app.database import Base
from app.main import app


@pytest.fixture()
def client():
    # StaticPool + check_same_thread=False keeps one shared in-memory
    # SQLite connection alive for the whole test, instead of each new
    # connection getting its own empty in-memory database.
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

    from app.models import response as _response_model  # noqa: F401 registers the model on Base
    Base.metadata.create_all(bind=engine)

    def override_get_db():
        db = TestingSessionLocal()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()
