"""tests/test_export.py — CSV/JSON export endpoints."""

import json


def _submit(client, answers: dict) -> str:
    response_id = client.post("/api/responses", json={}).json()["response_id"]
    client.put(f"/api/responses/{response_id}", json={"answers": answers})
    client.post(f"/api/responses/{response_id}/submit")
    return response_id


def test_csv_export_has_header_and_one_row_per_response(client):
    _submit(client, {"age": "25-34", "frustration-ranking": ["overloading", "heat", "loud-music",
                                                               "reckless-driving", "poor-service",
                                                               "dirty-vehicle", "long-wait"]})
    resp = client.get("/api/export/csv")

    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("text/csv")
    lines = resp.text.strip().splitlines()
    assert lines[0].startswith("response_id,submitted_at,age,")
    assert len(lines) == 2  # header + 1 response
    assert "25-34" in lines[1]
    assert "overloading > heat" in lines[1]  # ranking flattened with " > "


def test_csv_export_flattens_other_answer_shape(client):
    _submit(client, {"priority-feature": {"value": "other", "otherText": "Better lighting"}})
    resp = client.get("/api/export/csv")
    assert "Other: Better lighting" in resp.text


def test_json_export_is_valid_and_matches_saved_data(client):
    response_id = _submit(client, {"age": "under-18"})
    resp = client.get("/api/export/json")

    assert resp.status_code == 200
    payload = json.loads(resp.text)
    assert len(payload) == 1
    assert payload[0]["responseId"] == response_id
    assert payload[0]["answers"]["age"] == "under-18"


def test_export_excludes_unsubmitted_by_default(client):
    client.post("/api/responses", json={})  # never submitted
    resp = client.get("/api/export/json")
    assert json.loads(resp.text) == []
