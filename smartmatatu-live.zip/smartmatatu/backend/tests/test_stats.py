"""tests/test_stats.py — aggregation endpoints, with hand-picked answers
so the expected numbers are exact rather than approximate."""


def _submit(client, answers: dict) -> str:
    response_id = client.post("/api/responses", json={}).json()["response_id"]
    client.put(f"/api/responses/{response_id}", json={"answers": answers})
    client.post(f"/api/responses/{response_id}/submit")
    return response_id


def test_summary_with_no_data(client):
    body = client.get("/api/stats/summary").json()
    assert body["total_responses"] == 0
    assert body["average_safety"]["average"] is None
    assert body["future_participation_rate"] is None


def test_summary_averages_and_participation_rate(client):
    # safety: very-safe (best, score 5) and never-safe (worst, score 1) -> average 3.0
    _submit(client, {"safety": "very-safe", "future-participation": "yes"})
    _submit(client, {"safety": "never-safe", "future-participation": "no"})

    body = client.get("/api/stats/summary").json()
    assert body["total_responses"] == 2
    assert body["average_safety"]["average"] == 3.0
    assert body["average_safety"]["max_score"] == 5
    assert body["average_safety"]["sample_size"] == 2
    assert body["future_participation_rate"] == 50.0


def test_summary_excludes_not_sure_from_rating_average(client):
    _submit(client, {"comfort": "not-sure"})
    _submit(client, {"comfort": "very-comfortable"})  # best -> 5

    body = client.get("/api/stats/summary").json()
    assert body["average_comfort"]["sample_size"] == 1  # "not-sure" excluded
    assert body["average_comfort"]["average"] == 5.0


def test_distributions_count_each_option(client):
    _submit(client, {"age": "18-24"})
    _submit(client, {"age": "18-24"})
    _submit(client, {"age": "45-plus"})

    distributions = client.get("/api/stats/distributions").json()
    age = distributions["age"]
    assert age["labels"][1] == "18 - 24"
    assert age["values"][1] == 2
    assert age["labels"][-1] == "45+"
    assert age["values"][-1] == 1


def test_distributions_bucket_other_free_text_answers(client):
    _submit(client, {"priority-feature": {"value": "other", "otherText": "Better lighting"}})
    _submit(client, {"priority-feature": "no-overloading"})

    distributions = client.get("/api/stats/distributions").json()
    feature = distributions["priority_feature"]
    assert feature["labels"][-1] == "Other"
    assert feature["values"][-1] == 1


def test_frustration_ranking_orders_most_frustrating_first(client):
    # Every respondent ranks "overloading" as #1 (most frustrating) and
    # "heat" as #7 (least frustrating) — overloading should sort first.
    ranking = [
        "overloading", "loud-music", "reckless-driving",
        "poor-service", "dirty-vehicle", "long-wait", "heat",
    ]
    _submit(client, {"frustration-ranking": ranking})
    _submit(client, {"frustration-ranking": ranking})

    results = client.get("/api/stats/ranking").json()
    assert results[0]["value"] == "overloading"
    assert results[0]["average_rank"] == 1.0
    assert results[-1]["value"] == "heat"
    assert results[-1]["average_rank"] == 7.0
