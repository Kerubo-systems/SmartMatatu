"""
seed_test_data.py — dev utility, NOT part of the shipped app.

Posts a batch of realistic fake respondents to a running instance of this
API over real HTTP (not by touching the database directly), to prove the
full request path works the same way the frontend will use it. Mirrors
the branching logic from js/data/questions.js so generated respondents
are just as realistic as the ones from the dashboard's old mock data.

⚠️  DO NOT run this against your production/live backend — it will mix
fake respondents into your real research data. Use it only against a
local dev server (the default BASE_URL below), and if you ever do need
to clear fake data back out, see wipe_all_responses.py in this folder.
"""

import random
import string
import sys

import httpx

BASE_URL = "http://127.0.0.1:8000/api"

OPEN_ENDED_SAMPLES = {
    "never-used-reason": ["I usually drive my own car.", "I don't feel safe with the driving."],
    "most-valued": ["Punctuality.", "Friendly drivers.", "Low fares."],
    "annoyances": ["Overloading during rush hour.", "Loud music."],
    "one-improvement": ["Fixed, transparent fares.", "Stricter capacity enforcement."],
    "would-not-use-reason": ["Need to see it working reliably first."],
    "feedback": ["Thanks for looking into this.", ""],
}

QUESTIONS_ORDER = [
    ("age", "single-choice", ["under-18", "18-24", "25-34", "35-44", "45-plus"]),
    ("currently-uses-matatu", "single-choice", ["yes", "no"]),
]


def random_ranking():
    values = ["overloading", "heat", "loud-music", "reckless-driving", "poor-service", "dirty-vehicle", "long-wait"]
    random.shuffle(values)
    return values


def generate_answers():
    answers = {}
    answers["age"] = random.choice(["under-18", "18-24", "25-34", "35-44", "45-plus"])
    currently_uses = random.random() < 0.7
    answers["currently-uses-matatu"] = "yes" if currently_uses else "no"

    if currently_uses:
        pass
    else:
        ever_used = random.random() < 0.6
        answers["ever-used-matatu"] = "yes" if ever_used else "no"
        if not ever_used:
            answers["never-used-reason"] = random.choice(OPEN_ENDED_SAMPLES["never-used-reason"])

    if currently_uses or answers.get("ever-used-matatu") == "yes":
        answers["frequency"] = random.choice(["almost-daily", "weekly", "monthly", "rarely"])
        answers["most-valued"] = random.choice(OPEN_ENDED_SAMPLES["most-valued"])
        answers["annoyances"] = random.choice(OPEN_ENDED_SAMPLES["annoyances"])
        answers["safety"] = random.choice(["very-safe", "safe", "not-too-safe", "never-safe", "not-sure"])
        answers["comfort"] = random.choice(
            ["very-comfortable", "somewhat-comfortable", "very-little-comfort", "never-comfortable", "not-sure"]
        )
        answers["fare-fairness"] = random.choice(
            ["very-fair", "sometimes-fair", "averagely-fair", "rarely-fair", "never-fair"]
        )
        answers["overcharged"] = random.choice(["yes", "no"])
        answers["frustration-ranking"] = random_ranking()
        answers["one-improvement"] = random.choice(OPEN_ENDED_SAMPLES["one-improvement"])

    would_use = random.random() < 0.85
    answers["would-use-smartmatatu"] = "yes" if would_use else "no"
    if not would_use:
        answers["would-not-use-reason"] = random.choice(OPEN_ENDED_SAMPLES["would-not-use-reason"])

    if random.random() < 0.08:
        answers["priority-feature"] = {"value": "other", "otherText": "Better lighting at night stops."}
    else:
        answers["priority-feature"] = random.choice(
            ["collision-prevention", "no-overloading", "transparent-fares", "driver-monitoring", "electric-transport"]
        )

    answers["future-participation"] = random.choice(["yes", "no"])
    answers["feedback"] = random.choice(OPEN_ENDED_SAMPLES["feedback"])
    return answers


def seed(count: int):
    with httpx.Client(timeout=10) as client:
        for i in range(count):
            start = client.post(f"{BASE_URL}/responses", json={})
            start.raise_for_status()
            response_id = start.json()["response_id"]

            answers = generate_answers()
            save = client.put(f"{BASE_URL}/responses/{response_id}", json={"answers": answers})
            save.raise_for_status()

            submit = client.post(f"{BASE_URL}/responses/{response_id}/submit")
            submit.raise_for_status()

        print(f"Seeded {count} submitted responses.")


if __name__ == "__main__":
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 150
    seed(n)
