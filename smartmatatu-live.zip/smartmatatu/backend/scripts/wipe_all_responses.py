"""
wipe_all_responses.py — dev/ops utility, NOT part of the shipped app.

Deletes every response (submitted or not) from a running instance of
this API, over real HTTP, using the DELETE /api/responses/{id} endpoint.

USE THIS TO CLEAR OUT TEST/EXPERIMENTAL DATA before you start collecting
real responses — e.g. after you've clicked through the survey yourself
a few times to test the live deployment.

Requires typing "DELETE ALL" to confirm, and always prints which backend
URL it's about to hit first — read that line before confirming,
especially if you've pointed BASE_URL at a production deployment.
"""

import sys

import httpx

BASE_URL = "http://127.0.0.1:8000/api"


def wipe(base_url: str):
    with httpx.Client(timeout=10) as client:
        # submitted_only=false so this also clears abandoned/in-progress
        # test responses, not just completed ones.
        all_responses = client.get(f"{base_url}/responses", params={"submitted_only": "false"}).json()

        if not all_responses:
            print("No responses found — nothing to delete.")
            return

        print(f"About to permanently delete {len(all_responses)} response(s) from:\n  {base_url}\n")
        confirmation = input('Type "DELETE ALL" to confirm: ')
        if confirmation != "DELETE ALL":
            print("Cancelled — nothing was deleted.")
            return

        deleted = 0
        for response in all_responses:
            result = client.delete(f"{base_url}/responses/{response['response_id']}")
            if result.status_code == 204:
                deleted += 1
            else:
                print(f"  Could not delete {response['response_id']} (status {result.status_code})")

        print(f"Deleted {deleted}/{len(all_responses)} response(s).")


if __name__ == "__main__":
    url = sys.argv[1] if len(sys.argv) > 1 else BASE_URL
    wipe(url)
