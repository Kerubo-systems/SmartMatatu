# SmartMatatu Backend

FastAPI + SQLAlchemy API for the SmartMatatu survey and admin dashboard.

## Setup

```bash
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env            # optional — defaults already work
uvicorn app.main:app --reload
```

Visit `http://127.0.0.1:8000/docs` for interactive, auto-generated API
docs (FastAPI builds these from the Pydantic schemas and route
definitions — nothing extra to maintain).

## Architecture

```
api/routes/*.py     HTTP layer — parses requests, calls a service, returns a response.
                     No business logic or SQL here.
        |
services/*.py        Business logic. save_progress(), get_summary(), etc.
                      Framework-agnostic — no FastAPI or SQLAlchemy imports
                      beyond a Session type hint. Testable without HTTP.
        |
repositories/*.py     The ONLY place that writes SQLAlchemy queries.
                       Storage abstraction — see below.
        |
models/*.py            SQLAlchemy ORM table definitions.
        |
database.py             Engine/session setup. The one file that knows
                         which database dialect is in use.
```

Plus:
- `schemas/` — Pydantic request/response shapes (separate from the ORM
  models on purpose; what the API exposes and what's stored in the
  database are allowed to drift).
- `data/questions.py` — a Python-side copy of the question metadata
  needed for stats aggregation and CSV columns (see the comment in that
  file for why this is duplicated rather than shared, and how to fix
  that later if it becomes annoying).
- `config.py` — all environment-driven settings (database URL, CORS
  origins) in one place.

### Why a repository layer ("storage abstraction")

Every database read/write goes through `ResponseRepository`
(`repositories/response_repository.py`). Services and routes never
import a SQLAlchemy model directly or write a query. Concretely, this
means:

- **Moving to PostgreSQL is a one-line change** — edit `DATABASE_URL` in
  `.env`. `database.py` is the only file with any SQLite-specific code
  (a single `connect_args` line), and it's already written to skip that
  when the URL isn't SQLite.
- **Testing services doesn't need a real database setup opinion** — you
  can swap in a fake repository with the same method names.
- **If the schema needs to change** (e.g. splitting the single `answers`
  JSON column into a normalized answers table as the dataset grows),
  only `repositories/` and `models/` need to change. `services/` and
  `api/routes/` keep calling `response_repository.list_all(...)` etc.
  and don't notice the difference.

### Why FastAPI + this layering, specifically

You mentioned wanting this to scale toward AI/simulation/IoT work later.
The layering above is what makes that realistic:

- A future **AI/analytics service** can import
  `services/stats_service.py` directly (or add a new
  `services/insights_service.py` next to it) without touching routes or
  the database layer.
- A future **IoT ingestion endpoint** (e.g. vehicle sensor data) is just
  a new model + repository + service + route module, following the same
  four-layer pattern — it doesn't need to know anything about how survey
  responses are stored.
- FastAPI's dependency injection (`Depends(get_db)`) and Pydantic
  schemas are the same tools you'd reach for regardless of what's added
  next, so there's no rewrite needed to "make it scalable" later.

## API endpoints

| Method | Path | Purpose |
|---|---|---|
| POST | `/api/responses` | Start a new (empty) response, get back a `response_id` |
| PUT | `/api/responses/{response_id}` | Save/merge answers (called after each question) |
| POST | `/api/responses/{response_id}/submit` | Mark a response complete |
| GET | `/api/responses` | List responses (`?submitted_only=true/false`) |
| GET | `/api/responses/count` | Count of responses |
| GET | `/api/responses/{response_id}` | Fetch one response (used to resume an in-progress survey) |
| DELETE | `/api/responses/{response_id}` | Delete a response (dev/testing) |
| GET | `/api/stats/summary` | Headline stat card numbers |
| GET | `/api/stats/distributions` | Chart-ready category distributions |
| GET | `/api/stats/ranking` | Frustration ranking, sorted most → least frustrating |
| GET | `/api/export/csv` | Download all responses as CSV |
| GET | `/api/export/json` | Download all responses as JSON |

## Dev utility: seeding test data

```bash
python scripts/seed_test_data.py 150
```

Posts 150 realistic fake respondents to a **running** instance of this
API over real HTTP (not by touching the database directly) — useful for
trying out the dashboard without filling out the survey by hand.

## Tests

The endpoint behaviors (merge-on-save, submitted-only filtering,
404s, stats correctness, CSV/JSON export) were verified against a live
running instance during development — see the project's chat history /
commit notes for the exact request sequences used. Adding a proper
`tests/` suite with `pytest` + FastAPI's `TestClient` is a natural next
step; the layering above (services callable without HTTP) is what makes
that straightforward to add.
