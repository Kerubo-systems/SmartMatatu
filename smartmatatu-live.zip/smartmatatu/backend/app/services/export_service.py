"""
app/services/export_service.py

PURPOSE
Flattens response rows into CSV, the same way admin/api/export-api.js
used to do client-side against the mock dataset. Doing this server-side
means the export always reflects exactly what's in the database, and the
frontend export button becomes "download this URL" instead of needing to
fetch every response and build the file in the browser.
"""

import csv
import io
import json

from sqlalchemy.orm import Session

from app.data.questions import answerable_question_ids
from app.models.response import Response
from app.repositories.response_repository import response_repository


def _flatten_answer(answer) -> str:
    if answer is None:
        return ""
    if isinstance(answer, list):
        return " > ".join(str(v) for v in answer)  # ranking, most-frustrating first
    if isinstance(answer, dict) and answer.get("value") == "other":
        return f"Other: {answer.get('otherText', '')}"
    return str(answer)


def build_csv(db: Session, submitted_only: bool = True) -> str:
    responses: list[Response] = response_repository.list_all(db, submitted_only=submitted_only)
    question_columns = answerable_question_ids()

    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(["response_id", "submitted_at", *question_columns])

    for response in responses:
        submitted_at = response.submitted_at.isoformat() if response.submitted_at else ""
        row = [response.response_id, submitted_at]
        row += [_flatten_answer((response.answers or {}).get(qid)) for qid in question_columns]
        writer.writerow(row)

    return buffer.getvalue()


def build_json(db: Session, submitted_only: bool = True) -> str:
    responses: list[Response] = response_repository.list_all(db, submitted_only=submitted_only)
    payload = [
        {
            "responseId": r.response_id,
            "submittedAt": r.submitted_at.isoformat() if r.submitted_at else None,
            "answers": r.answers or {},
        }
        for r in responses
    ]
    return json.dumps(payload, indent=2)
