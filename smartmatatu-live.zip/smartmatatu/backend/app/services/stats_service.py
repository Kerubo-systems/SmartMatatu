"""
app/services/stats_service.py

PURPOSE
Computes the same aggregates the dashboard needs (averages, category
distributions, frustration ranking) but server-side, in Python, against
real database rows. This deliberately mirrors the logic that used to
live in admin/api/stats-api.js for the mock data — same 1-5 rescaling
approach, same "exclude not-sure from the rating scale" rule — so moving
from mock data to real data doesn't change what a "safety rating of 3.8"
means.
"""

from sqlalchemy.orm import Session

from app.data.questions import QUESTIONS, get_question
from app.models.response import Response
from app.repositories.response_repository import response_repository

# Ordered best-to-worst option values for each rating question, with
# "not sure" deliberately excluded — it's a valid answer, but doesn't
# belong on a 1-5 rating scale. Kept in sync with the equivalent table in
# admin/api/stats-api.js.
RATING_SCALES: dict[str, list[str]] = {
    "safety": ["very-safe", "safe", "not-too-safe", "never-safe"],
    "comfort": ["very-comfortable", "somewhat-comfortable", "very-little-comfort", "never-comfortable"],
    "fare-fairness": ["very-fair", "sometimes-fair", "averagely-fair", "rarely-fair", "never-fair"],
}

RATING_SCALE_MAX = 5


def _average_score(responses: list[Response], question_id: str) -> dict:
    scale = RATING_SCALES[question_id]
    step = (RATING_SCALE_MAX - 1) / (len(scale) - 1) if len(scale) > 1 else 0
    scored: list[float] = []

    for response in responses:
        answer = (response.answers or {}).get(question_id)
        if answer in scale:
            position = scale.index(answer)
            scored.append(RATING_SCALE_MAX - position * step)

    if not scored:
        return {"average": None, "max_score": RATING_SCALE_MAX, "sample_size": 0}

    average = round(sum(scored) / len(scored), 1)
    return {"average": average, "max_score": RATING_SCALE_MAX, "sample_size": len(scored)}


def _distribution(responses: list[Response], question_id: str) -> dict:
    question = get_question(question_id)
    known_values = [opt.value for opt in question.options] if question else []
    counts: dict[str, int] = {value: 0 for value in known_values}
    other_count = 0

    for response in responses:
        answer = (response.answers or {}).get(question_id)
        if answer is None:
            continue
        # A single-choice "other" answer arrives as {"value": "other", "otherText": "..."}
        if isinstance(answer, dict):
            answer = answer.get("value")
        if answer in counts:
            counts[answer] += 1
        else:
            other_count += 1

    labels = [opt.label for opt in question.options] if question else []
    values = [counts[opt.value] for opt in question.options] if question else []
    if other_count > 0:
        labels.append("Other")
        values.append(other_count)

    return {"labels": labels, "values": values}


def get_summary(db: Session) -> dict:
    responses = response_repository.list_all(db, submitted_only=True)

    safety = _average_score(responses, "safety")
    comfort = _average_score(responses, "comfort")
    fare = _average_score(responses, "fare-fairness")

    participation_answers = [
        (r.answers or {}).get("future-participation")
        for r in responses
        if (r.answers or {}).get("future-participation") is not None
    ]
    yes_count = sum(1 for a in participation_answers if a == "yes")
    participation_rate = (
        round((yes_count / len(participation_answers)) * 1000) / 10 if participation_answers else None
    )

    return {
        "total_responses": len(responses),
        "average_safety": safety,
        "average_comfort": comfort,
        "average_fare_fairness": fare,
        "future_participation_rate": participation_rate,
    }


def get_distributions(db: Session) -> dict:
    responses = response_repository.list_all(db, submitted_only=True)
    return {
        "age": _distribution(responses, "age"),
        "frequency": _distribution(responses, "frequency"),
        "safety": _distribution(responses, "safety"),
        "comfort": _distribution(responses, "comfort"),
        "fare_fairness": _distribution(responses, "fare-fairness"),
        "priority_feature": _distribution(responses, "priority-feature"),
    }


def get_frustration_ranking(db: Session) -> list[dict]:
    responses = response_repository.list_all(db, submitted_only=True)
    question = get_question("frustration-ranking")
    totals = {opt.value: 0 for opt in question.options}
    counts = {opt.value: 0 for opt in question.options}

    for response in responses:
        ranking = (response.answers or {}).get("frustration-ranking")
        if not isinstance(ranking, list):
            continue
        for index, value in enumerate(ranking):
            if value not in totals:
                continue
            totals[value] += index + 1  # rank position, 1 = most frustrating
            counts[value] += 1

    results = [
        {
            "value": opt.value,
            "label": opt.label,
            "average_rank": round(totals[opt.value] / counts[opt.value], 2) if counts[opt.value] else None,
        }
        for opt in question.options
    ]
    results.sort(key=lambda r: (r["average_rank"] is None, r["average_rank"]))
    return results
