"""
app/services/response_service.py

PURPOSE
Business logic for survey responses sits here, between the API routes
and the repository. Routes should stay "thin" — parse the request,
call a service method, return the result. Anything with actual logic
(how a response id is generated, what "submit" means) belongs here so
it's testable without spinning up HTTP at all, and so it isn't duplicated
if a second entry point (e.g. a future admin "create test response"
tool) needs the same behaviour.
"""

import random
import string
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.models.response import Response
from app.repositories.response_repository import response_repository


class ResponseNotFoundError(Exception):
    pass


class ResponseService:

    def _generate_response_id(self, db: Session) -> str:
        """
        Mirrors the format the frontend used to generate client-side
        (SM-<year>-<6 random base36 chars>), now generated server-side so
        two respondents can never collide on the same id.
        """
        year = datetime.now(timezone.utc).year
        alphabet = string.ascii_uppercase + string.digits
        for _ in range(10):  # a handful of retries is effectively unlimited given the keyspace
            candidate = f"SM-{year}-{''.join(random.choices(alphabet, k=6))}"
            if not response_repository.exists(db, candidate):
                return candidate
        raise RuntimeError("Could not generate a unique response id — this should never happen.")

    def start_response(self, db: Session) -> Response:
        """Creates a brand-new, empty response and returns it (id included)."""
        response_id = self._generate_response_id(db)
        return response_repository.create(db, response_id)

    def get_response(self, db: Session, response_id: str) -> Response:
        response = response_repository.get_by_response_id(db, response_id)
        if response is None:
            raise ResponseNotFoundError(response_id)
        return response

    def save_progress(self, db: Session, response_id: str, answers: dict) -> Response:
        """
        Saves (merges) one or more answers for a response, creating the
        response if this is the first time we've seen this id. This
        makes the endpoint idempotent-friendly for a survey that saves
        after every question, which is how the frontend already behaves.
        """
        return response_repository.upsert_answers(db, response_id, answers)

    def submit_response(self, db: Session, response_id: str) -> Response:
        response = response_repository.mark_submitted(db, response_id)
        if response is None:
            raise ResponseNotFoundError(response_id)
        return response

    def list_responses(self, db: Session, submitted_only: bool = True) -> list[Response]:
        return response_repository.list_all(db, submitted_only=submitted_only)

    def count_responses(self, db: Session, submitted_only: bool = True) -> int:
        return response_repository.count(db, submitted_only=submitted_only)

    def delete_response(self, db: Session, response_id: str) -> bool:
        return response_repository.delete(db, response_id)


response_service = ResponseService()
