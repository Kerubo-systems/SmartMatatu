"""
app/data/questions.py

PURPOSE
A Python-side copy of the question metadata (id, type, options) that the
frontend defines in js/data/questions.js. The backend needs this to know,
for example, which options exist for "safety" so it can build a
distribution chart, or the full list of question ids so CSV export has
consistent columns.

IMPORTANT — KEEPING THIS IN SYNC
This is intentionally duplicated rather than shared, because the survey
frontend and this backend are different languages. If you add, rename,
or remove a question in js/data/questions.js, mirror that change here too.
Only what the backend actually needs is copied — full question text and
skip-logic branching stay in the frontend, since only the frontend
renders and navigates the survey.

If this ever becomes a real maintenance headache, the cleanest fix is to
make ONE canonical questions.json file that both js/data/questions.js and
this module load at runtime, instead of hand-maintaining two copies. That
is a reasonable V2 improvement, not required to ship this backend.
"""

from dataclasses import dataclass, field


@dataclass(frozen=True)
class QuestionOption:
    value: str
    label: str


@dataclass(frozen=True)
class QuestionMeta:
    id: str
    type: str  # "single-choice" | "open-ended" | "ranking" | "info"
    options: list[QuestionOption] = field(default_factory=list)


QUESTIONS: list[QuestionMeta] = [
    QuestionMeta("age", "single-choice", [
        QuestionOption("under-18", "Under 18"),
        QuestionOption("18-24", "18 - 24"),
        QuestionOption("25-34", "25 - 34"),
        QuestionOption("35-44", "35 - 44"),
        QuestionOption("45-plus", "45+"),
    ]),
    QuestionMeta("currently-uses-matatu", "single-choice", [
        QuestionOption("yes", "Yes"), QuestionOption("no", "No"),
    ]),
    QuestionMeta("ever-used-matatu", "single-choice", [
        QuestionOption("yes", "Yes"), QuestionOption("no", "No"),
    ]),
    QuestionMeta("never-used-reason", "open-ended"),
    QuestionMeta("frequency", "single-choice", [
        QuestionOption("almost-daily", "Almost daily"),
        QuestionOption("weekly", "Once or twice a week"),
        QuestionOption("monthly", "A few times a month"),
        QuestionOption("rarely", "Not so often"),
    ]),
    QuestionMeta("most-valued", "open-ended"),
    QuestionMeta("annoyances", "open-ended"),
    QuestionMeta("safety", "single-choice", [
        QuestionOption("very-safe", "Very safe"),
        QuestionOption("safe", "Safe"),
        QuestionOption("not-too-safe", "Not too safe"),
        QuestionOption("never-safe", "Never safe"),
        QuestionOption("not-sure", "Not sure"),
    ]),
    QuestionMeta("comfort", "single-choice", [
        QuestionOption("very-comfortable", "Very comfortable"),
        QuestionOption("somewhat-comfortable", "Somewhat comfortable"),
        QuestionOption("very-little-comfort", "Very little comfort"),
        QuestionOption("never-comfortable", "Never comfortable"),
        QuestionOption("not-sure", "Not sure"),
    ]),
    QuestionMeta("fare-fairness", "single-choice", [
        QuestionOption("very-fair", "Very fair"),
        QuestionOption("sometimes-fair", "Sometimes fair"),
        QuestionOption("averagely-fair", "Averagely fair"),
        QuestionOption("rarely-fair", "Rarely fair"),
        QuestionOption("never-fair", "Never fair"),
    ]),
    QuestionMeta("overcharged", "single-choice", [
        QuestionOption("yes", "Yes"), QuestionOption("no", "No"),
    ]),
    QuestionMeta("frustration-ranking", "ranking", [
        QuestionOption("overloading", "Overloading"),
        QuestionOption("heat", "Heat"),
        QuestionOption("loud-music", "Loud music"),
        QuestionOption("reckless-driving", "Reckless driving"),
        QuestionOption("poor-service", "Poor customer service"),
        QuestionOption("dirty-vehicle", "Dirty vehicle"),
        QuestionOption("long-wait", "Long waiting time"),
    ]),
    QuestionMeta("one-improvement", "open-ended"),
    QuestionMeta("would-use-smartmatatu", "single-choice", [
        QuestionOption("yes", "Yes"), QuestionOption("no", "No"),
    ]),
    QuestionMeta("would-not-use-reason", "open-ended"),
    QuestionMeta("feature-intro", "info"),
    QuestionMeta("priority-feature", "single-choice", [
        QuestionOption("collision-prevention", "Automatic collision prevention"),
        QuestionOption("no-overloading", "No overloading"),
        QuestionOption("transparent-fares", "Transparent digital fares"),
        QuestionOption("driver-monitoring", "Driver behaviour monitoring"),
        QuestionOption("electric-transport", "Cleaner electric transport"),
        QuestionOption("other", "Other"),
    ]),
    QuestionMeta("future-participation", "single-choice", [
        QuestionOption("yes", "Yes"), QuestionOption("no", "No"),
    ]),
    QuestionMeta("feedback", "open-ended"),
]

_BY_ID: dict[str, QuestionMeta] = {q.id: q for q in QUESTIONS}


def get_question(question_id: str) -> QuestionMeta | None:
    return _BY_ID.get(question_id)


def answerable_question_ids() -> list[str]:
    """Every question id that can carry an answer, in survey order (skips 'info' slides)."""
    return [q.id for q in QUESTIONS if q.type != "info"]
