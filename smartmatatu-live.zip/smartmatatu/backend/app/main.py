"""
app/main.py

PURPOSE
The FastAPI application object. Deliberately small: create the app,
attach CORS, mount each router, create tables on startup. All real logic
lives in services/repositories; all endpoint definitions live in
api/routes/.

RUNNING
    uvicorn app.main:app --reload

Then visit http://127.0.0.1:8000/docs for interactive API docs (FastAPI
generates these automatically from the Pydantic schemas and route
definitions above).
"""

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes import export, responses, stats
from app.config import get_settings
from app.database import init_db

settings = get_settings()


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    yield


app = FastAPI(
    title=settings.app_name,
    description="API for the SmartMatatu Passenger Experience Study — survey responses and research dashboard stats.",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/", tags=["health"])
def health_check() -> dict:
    return {"status": "ok", "service": settings.app_name}


app.include_router(responses.router, prefix=settings.api_prefix)
app.include_router(stats.router, prefix=settings.api_prefix)
app.include_router(export.router, prefix=settings.api_prefix)
