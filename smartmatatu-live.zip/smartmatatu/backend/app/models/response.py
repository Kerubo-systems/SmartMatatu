"""
app/models/response.py

PURPOSE
The single database table this app needs for V1: one row per survey
respondent. All their question answers live together in one JSON column
rather than one row per answer.

WHY ONE JSON COLUMN INSTEAD OF ONE ROW PER ANSWER
Answers come in different shapes depending on question type (a plain
string for open-ended, an ordered array for ranking, an object for
"other" free text on a single-choice). A fully normalized schema (one
"answers" table with question_id/value columns) would need a different
column per possible value type, or a generic "value" text column plus
application-level parsing either way. For a research survey of this
size, storing the whole answers dict as JSON is simpler, matches the
shape the frontend already works with (window.SmartMatatu.Storage's
in-memory answers object), and is still queryable — SQLite and
PostgreSQL both support JSON columns.

If the dataset grows large enough that per-question SQL filtering
becomes a real performance need, this is the table to split into a
proper answers table — nothing above this file needs to change to do
that, since all reads/writes go through ResponseRepository.
"""

from datetime import datetime, timezone

from sqlalchemy import Boolean, Column, DateTime, Integer, JSON, String

from app.database import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Response(Base):
    __tablename__ = "responses"

    id = Column(Integer, primary_key=True, index=True)

    # Public-facing identifier shown to respondents (e.g. "SM-2026-AB12CD").
    # Distinct from the internal `id` so we never expose database row
    # numbers, and so the format can stay stable even if storage changes.
    response_id = Column(String(32), unique=True, index=True, nullable=False)

    # The full { question_id: answer } dict. Merged (not replaced) on
    # every save so partial progress is never lost — see
    # ResponseRepository.upsert_answers.
    answers = Column(JSON, nullable=False, default=dict)

    is_submitted = Column(Boolean, nullable=False, default=False)

    created_at = Column(DateTime(timezone=True), default=_utcnow, nullable=False)
    updated_at = Column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow, nullable=False)
    submitted_at = Column(DateTime(timezone=True), nullable=True)
