"""
app/schemas/response.py

PURPOSE
Pydantic models define exactly what shape of JSON the API accepts and
returns. FastAPI uses these to validate incoming requests automatically
(bad requests get a 422 with a clear error, before any of our code runs)
and to build the interactive API docs at /docs.

These are deliberately separate from app/models/response.py (the
database table). Request/response shapes and database columns often
drift apart over time — e.g. we may never want to expose the internal
`id` column - keeping them separate means that's a design choice, not an
accident.
"""

from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class ResponseCreate(BaseModel):
    """Body for POST /api/responses - starts a new response."""
    # Answers can optionally be provided up front, but usually a new
    # response starts empty and answers arrive via PUT as the respondent
    # progresses through the survey.
    answers: dict[str, Any] = Field(default_factory=dict)


class AnswersUpdate(BaseModel):
    """Body for PUT /api/responses/{response_id} - saves progress."""
    answers: dict[str, Any] = Field(
        ..., description="One or more { question_id: answer } pairs to merge into this response."
    )


class ResponseOut(BaseModel):
    """What the API returns for a single response."""
    model_config = ConfigDict(from_attributes=True)

    response_id: str
    answers: dict[str, Any]
    is_submitted: bool
    created_at: datetime
    updated_at: datetime
    submitted_at: datetime | None = None


class ResponseCountOut(BaseModel):
    count: int
