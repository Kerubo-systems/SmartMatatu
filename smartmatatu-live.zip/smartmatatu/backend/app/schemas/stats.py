"""
app/schemas/stats.py

PURPOSE
Response shapes for /api/stats/*. These mirror exactly what the
dashboard's admin/api/stats-api.js already expects, since that file's
job (after this backend exists) is just to fetch() these endpoints and
hand the JSON straight to the charts.
"""

from pydantic import BaseModel


class ScoreOut(BaseModel):
    average: float | None
    max_score: int
    sample_size: int


class SummaryOut(BaseModel):
    total_responses: int
    average_safety: ScoreOut
    average_comfort: ScoreOut
    average_fare_fairness: ScoreOut
    future_participation_rate: float | None


class DistributionOut(BaseModel):
    labels: list[str]
    values: list[int]


class DistributionsOut(BaseModel):
    age: DistributionOut
    frequency: DistributionOut
    safety: DistributionOut
    comfort: DistributionOut
    fare_fairness: DistributionOut
    priority_feature: DistributionOut


class RankingResultOut(BaseModel):
    value: str
    label: str
    average_rank: float | None
