"""
app/api/routes/responses.py

PURPOSE
HTTP endpoints for survey responses. Kept thin on purpose: parse/validate
the request (via the Pydantic schemas), delegate to ResponseService, map
the result (or a not-found error) onto an HTTP response. No business
logic or database queries live in this file.

ENDPOINT SUMMARY
  POST   /api/responses                 start a new (empty) response
  PUT    /api/responses/{response_id}   save/merge progress (called after each answer)
  POST   /api/responses/{response_id}/submit   mark a response as complete
  GET    /api/responses                 list responses (dashboard)
  GET    /api/responses/count           just the count
  GET    /api/responses/{response_id}   fetch one response (e.g. to resume a survey)
  DELETE /api/responses/{response_id}   remove a response (dev/testing utility)
"""

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.schemas.response import AnswersUpdate, ResponseCountOut, ResponseCreate, ResponseOut
from app.services.response_service import ResponseNotFoundError, response_service

router = APIRouter(prefix="/responses", tags=["responses"])


@router.post("", response_model=ResponseOut, status_code=201)
def start_response(payload: ResponseCreate | None = None, db: Session = Depends(get_db)):
    """Creates a new response and returns its generated response_id."""
    response = response_service.start_response(db)
    if payload and payload.answers:
        response = response_service.save_progress(db, response.response_id, payload.answers)
    return response


@router.put("/{response_id}", response_model=ResponseOut)
def save_progress(response_id: str, payload: AnswersUpdate, db: Session = Depends(get_db)):
    """
    Saves (merges) answers for an in-progress response. Called after
    every question the respondent answers — safe to call repeatedly,
    since answers are merged rather than replaced.
    """
    return response_service.save_progress(db, response_id, payload.answers)


@router.post("/{response_id}/submit", response_model=ResponseOut)
def submit_response(response_id: str, db: Session = Depends(get_db)):
    try:
        return response_service.submit_response(db, response_id)
    except ResponseNotFoundError:
        raise HTTPException(status_code=404, detail=f"No response found with id '{response_id}'.")


@router.get("", response_model=list[ResponseOut])
def list_responses(
    submitted_only: bool = Query(True, description="If false, includes in-progress responses too."),
    db: Session = Depends(get_db),
):
    return response_service.list_responses(db, submitted_only=submitted_only)


@router.get("/count", response_model=ResponseCountOut)
def count_responses(
    submitted_only: bool = Query(True),
    db: Session = Depends(get_db),
):
    return {"count": response_service.count_responses(db, submitted_only=submitted_only)}


@router.get("/{response_id}", response_model=ResponseOut)
def get_response(response_id: str, db: Session = Depends(get_db)):
    try:
        return response_service.get_response(db, response_id)
    except ResponseNotFoundError:
        raise HTTPException(status_code=404, detail=f"No response found with id '{response_id}'.")


@router.delete("/{response_id}", status_code=204)
def delete_response(response_id: str, db: Session = Depends(get_db)):
    deleted = response_service.delete_response(db, response_id)
    if not deleted:
        raise HTTPException(status_code=404, detail=f"No response found with id '{response_id}'.")
