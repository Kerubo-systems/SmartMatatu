"""
app/api/routes/stats.py

PURPOSE
Read-only aggregate endpoints for the dashboard's Home and Ranking
Analysis sections. All the actual math lives in app/services/stats_service.py
— these routes just call it and let the Pydantic response_model validate
the shape on the way out.
"""

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.schemas.stats import DistributionsOut, RankingResultOut, SummaryOut
from app.services import stats_service

router = APIRouter(prefix="/stats", tags=["stats"])


@router.get("/summary", response_model=SummaryOut)
def get_summary(db: Session = Depends(get_db)):
    return stats_service.get_summary(db)


@router.get("/distributions", response_model=DistributionsOut)
def get_distributions(db: Session = Depends(get_db)):
    return stats_service.get_distributions(db)


@router.get("/ranking", response_model=list[RankingResultOut])
def get_ranking(db: Session = Depends(get_db)):
    return stats_service.get_frustration_ranking(db)
