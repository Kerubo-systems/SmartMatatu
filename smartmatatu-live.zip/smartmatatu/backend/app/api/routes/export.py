"""
app/api/routes/export.py

PURPOSE
Streams a CSV or JSON file of all responses, built by
app/services/export_service.py. The dashboard's Export CSV/Export JSON
buttons just point the browser at these URLs (or fetch + save-as), so
the file always reflects the current database contents.
"""

from datetime import date

from fastapi import APIRouter, Depends, Query
from fastapi.responses import Response as FastAPIResponse
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.services import export_service

router = APIRouter(prefix="/export", tags=["export"])


@router.get("/csv")
def export_csv(submitted_only: bool = Query(True), db: Session = Depends(get_db)):
    csv_content = export_service.build_csv(db, submitted_only=submitted_only)
    filename = f"smartmatatu-responses-{date.today().isoformat()}.csv"
    return FastAPIResponse(
        content=csv_content,
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/json")
def export_json(submitted_only: bool = Query(True), db: Session = Depends(get_db)):
    json_content = export_service.build_json(db, submitted_only=submitted_only)
    filename = f"smartmatatu-responses-{date.today().isoformat()}.json"
    return FastAPIResponse(
        content=json_content,
        media_type="application/json",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
