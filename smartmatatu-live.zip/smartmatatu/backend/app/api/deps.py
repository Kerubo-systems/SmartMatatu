"""
app/api/deps.py

PURPOSE
FastAPI dependencies used across route files. `get_db` is the standard
SQLAlchemy-with-FastAPI pattern: open one session per request, always
close it afterwards (even if the request raised an error), and let
FastAPI inject it into any route that asks for it via `Depends(get_db)`.
"""

from collections.abc import Generator

from sqlalchemy.orm import Session

from app.database import SessionLocal


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
