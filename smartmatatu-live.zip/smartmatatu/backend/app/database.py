"""
app/database.py

PURPOSE
Sets up the SQLAlchemy engine and session factory. This is intentionally
tiny and boring — it should never need application-specific logic. The
`connect_args` line is the ONLY piece of code in this entire backend that
is SQLite-specific; everything above the database (repositories,
services, routes) talks to SQLAlchemy's generic API and would work
unchanged against PostgreSQL.
"""

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

from app.config import get_settings

settings = get_settings()

# `check_same_thread` is only needed for SQLite (it's not thread-safe by
# default, and FastAPI can handle a request on a different thread than it
# was opened on). PostgreSQL connection strings simply won't have this
# kwarg applied.
connect_args = {"check_same_thread": False} if settings.database_url.startswith("sqlite") else {}

engine = create_engine(settings.database_url, connect_args=connect_args)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# All ORM models inherit from this. Kept here (not in models/) so models
# and database.py don't import each other in a circle.
Base = declarative_base()


def init_db() -> None:
    """
    Creates all tables that don't exist yet. Safe to call every startup —
    it never drops or alters existing tables. For real schema changes
    later (adding a column, etc.), swap this for a migration tool like
    Alembic; this function is a V1 convenience, not a migration system.
    """
    from app.models import response  # noqa: F401  (ensures model is registered on Base)
    Base.metadata.create_all(bind=engine)
