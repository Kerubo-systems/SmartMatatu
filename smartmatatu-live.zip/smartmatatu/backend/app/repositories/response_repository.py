"""
app/repositories/response_repository.py

PURPOSE
This is the storage abstraction layer. Every database read/write for
survey responses goes through this class — nowhere else in the app
(services, routes) is allowed to import SQLAlchemy models directly or
write a query. That's what makes the SQLite -> PostgreSQL move later a
one-line config change (app/config.py's database_url) instead of a
rewrite: the engine underneath SQLAlchemy changes, but every call site
above this file stays identical.

Each method takes a `db: Session` rather than opening its own connection,
so FastAPI's dependency injection (see app/api/deps.py) controls the
session's lifetime — one session per request, closed automatically when
the request finishes.
"""

from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.models.response import Response


class ResponseRepository:

    def create(self, db: Session, response_id: str, initial_answers: dict | None = None) -> Response:
        response = Response(response_id=response_id, answers=initial_answers or {})
        db.add(response)
        db.commit()
        db.refresh(response)
        return response

    def get_by_response_id(self, db: Session, response_id: str) -> Response | None:
        return db.query(Response).filter(Response.response_id == response_id).first()

    def exists(self, db: Session, response_id: str) -> bool:
        return self.get_by_response_id(db, response_id) is not None

    def upsert_answers(self, db: Session, response_id: str, new_answers: dict) -> Response:
        """
        Merges `new_answers` into the response's existing answers dict
        (creating the response first if this is the very first save for
        that id), rather than overwriting the whole answers column. This
        means saving one question's answer can never wipe out answers
        already saved for other questions.
        """
        response = self.get_by_response_id(db, response_id)
        if response is None:
            response = Response(response_id=response_id, answers={})
            db.add(response)

        # SQLAlchemy's JSON column doesn't track in-place dict mutation,
        # so build a new dict and reassign it — this is what makes the
        # UPDATE actually happen.
        merged = {**(response.answers or {}), **new_answers}
        response.answers = merged
        response.updated_at = datetime.now(timezone.utc)

        db.commit()
        db.refresh(response)
        return response

    def mark_submitted(self, db: Session, response_id: str) -> Response | None:
        response = self.get_by_response_id(db, response_id)
        if response is None:
            return None
        response.is_submitted = True
        response.submitted_at = datetime.now(timezone.utc)
        db.commit()
        db.refresh(response)
        return response

    def list_all(self, db: Session, submitted_only: bool = True) -> list[Response]:
        query = db.query(Response)
        if submitted_only:
            query = query.filter(Response.is_submitted.is_(True))
        return query.order_by(Response.submitted_at.desc().nullslast()).all()

    def count(self, db: Session, submitted_only: bool = True) -> int:
        query = db.query(Response)
        if submitted_only:
            query = query.filter(Response.is_submitted.is_(True))
        return query.count()

    def delete(self, db: Session, response_id: str) -> bool:
        response = self.get_by_response_id(db, response_id)
        if response is None:
            return False
        db.delete(response)
        db.commit()
        return True


# A single shared instance is fine here: the class holds no state of its
# own (every method receives its db session as an argument), so there's
# nothing to isolate between requests.
response_repository = ResponseRepository()
