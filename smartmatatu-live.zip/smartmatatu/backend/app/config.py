"""
app/config.py

PURPOSE
Every value that changes between "my laptop" and "a real server" lives
here, read from environment variables (with sane defaults for local dev).
This is THE file you edit to move from SQLite to PostgreSQL later:
just set DATABASE_URL in a .env file or the environment. No other file
in the backend needs to know or care which database is actually in use —
that's the whole point of the storage layer described in the README.
"""

from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # --- App identity ---------------------------------------------------
    app_name: str = "SmartMatatu API"
    api_prefix: str = "/api"

    # --- Database ---------------------------------------------------------
    # SQLite for local development. To move to PostgreSQL later, set this
    # to e.g. "postgresql+psycopg2://user:password@host:5432/smartmatatu"
    # in a .env file — SQLAlchemy (via the repository layer) handles the
    # rest, and no application code changes are required.
    database_url: str = "sqlite:///./smartmatatu.db"

    # --- CORS ---------------------------------------------------------------
    # The survey and dashboard are static files, often served from a
    # different origin/port than the API during development (e.g. a
    # simple `python -m http.server`). List every origin that's allowed
    # to call this API. Comma-separated in the environment variable.
    cors_allowed_origins: str = "http://localhost:5500,http://127.0.0.1:5500,http://localhost:8080,http://127.0.0.1:8080,http://localhost:3000"

    @property
    def cors_origins_list(self) -> list[str]:
        return [origin.strip() for origin in self.cors_allowed_origins.split(",") if origin.strip()]

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")


@lru_cache
def get_settings() -> Settings:
    # Cached so Settings() (which reads the environment/`.env`) only runs
    # once per process instead of on every request.
    return Settings()
