# SmartMatatu

Independent engineering research project exploring how technology can
improve safety, accountability, comfort, and sustainability in Kenyan
public transportation.

## Project pieces

| Folder | What it is | Runs as |
|---|---|---|
| `/` (`index.html`, `survey.html`, `thank-you.html`, `js/`, `css/`) | The public passenger survey | Static files |
| `admin/` | Private research dashboard | Static files |
| `backend/` | FastAPI + SQLite (or PostgreSQL) API both of the above talk to | Python server |

The survey and dashboard both read/write **real backend data only** —
there's no mock or demo data built into either. If the backend isn't
running, the survey shows a connection error instead of losing an
answer, and the dashboard shows an explicit "couldn't load data" state
instead of any placeholder numbers.

## Running it locally

**1. Start the backend** (see `backend/README.md` for full detail):

```bash
cd backend
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

**2. Serve the frontend** (a second terminal, from the project root):

```bash
python3 -m http.server 5500
```

- Survey: `http://localhost:5500/index.html`
- Dashboard: `http://localhost:5500/admin/index.html`

## Getting real responses from real people

See **`DEPLOYMENT.md`** for the full step-by-step: pushing to GitHub,
deploying the backend (Render + free PostgreSQL) and the survey's static
files (Netlify), pointing `js/config.js` at the live backend, and
clearing out any test responses before sharing the link.

Dev-only helper scripts live in `backend/scripts/`:
- `seed_test_data.py` — posts realistic fake respondents to a **local**
  dev server only. Never run this against your live backend.
- `wipe_all_responses.py` — deletes every response from whatever backend
  URL you point it at, after a typed confirmation. Use this to clear out
  test submissions before real launch.

## How the pieces talk to each other

```
survey (fetch)  ──POST/PUT──>  FastAPI backend  ──SQLAlchemy──>  SQLite / PostgreSQL
                                      |
dashboard (fetch)  <──GET── (stats, responses, CSV/JSON export)
```

`js/config.js` holds `API_BASE_URL` — the one line to change when the
backend moves from your machine to a real deployment.

## Moving to PostgreSQL

Change one line in `backend/.env` (copy from `.env.example`):

```
DATABASE_URL=postgresql+psycopg2://user:password@host:5432/smartmatatu
```

...install the driver (`pip install psycopg2-binary`), and nothing else
changes — see `backend/README.md` for why. `DEPLOYMENT.md` walks through
doing exactly this on Render's free tier.

## Current Version

Version 2 — connected to a real FastAPI backend, mock/demo data removed.

## Future Plans

- Authentication for the admin dashboard
- Data analytics / AI-assisted insights
- Driver, Prototype Testing, and Accessibility surveys (see Survey Manager)

## Author

Ashley Kerubo
