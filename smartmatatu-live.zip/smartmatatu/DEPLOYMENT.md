# Deploying SmartMatatu for real respondents

This gets you two public URLs:
- a **survey link** you hand out to real people
- a **backend API** the survey (and your local dashboard) talk to

The admin dashboard is deliberately **not** part of this public deployment
— see "Keeping the dashboard private" at the bottom.

Recommended stack (both free to start): **Render** for the backend +
its free PostgreSQL database, **Netlify** for the survey's static files.
Any host that runs a Python web service / serves static files works too
— the steps below are the same idea wherever you deploy.

---

## 1. Put the code on GitHub

Render and Netlify both deploy straight from a GitHub repo.

```bash
cd smartmatatu
git init
git add .
git commit -m "SmartMatatu v2 — real backend"
```

Create a new (private is fine) repo on GitHub, then push:

```bash
git remote add origin https://github.com/<you>/smartmatatu.git
git push -u origin main
```

## 2. Deploy the backend on Render

1. [render.com](https://render.com) → **New +** → **Web Service** → connect
   your `smartmatatu` repo.
2. Settings:
   - **Root Directory**: `backend`
   - **Runtime**: Python 3
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
     (this is also in `backend/Procfile`, which Render can pick up
     automatically)
   - **Instance Type**: Free

3. **Add a real database** — this is the important part. SQLite files
   don't survive Render's free-tier disk being wiped on redeploy, so for
   real data collection:
   - Render dashboard → **New +** → **PostgreSQL** → free tier.
     (Free Postgres on Render expires after 90 days — fine for a survey
     that runs for a few weeks; if your study runs longer, plan to
     upgrade or export your data with `GET /api/export/json` before
     then.)
   - Copy the **Internal Database URL** it gives you.
   - Back in your Web Service → **Environment** → add:
     ```
     DATABASE_URL = postgresql+psycopg2://... (paste the Internal Database URL, keep the +psycopg2 part)
     ```
   - Add `psycopg2-binary` to `backend/requirements.txt` (uncomment the
     line that's already there) and push that change.

4. **CORS** — add another environment variable once you know your
   frontend's URL (step 3 gives you this):
   ```
   CORS_ALLOWED_ORIGINS = https://your-survey-site.netlify.app
   ```

5. Deploy. Render gives you a URL like
   `https://smartmatatu-api.onrender.com`. Visit
   `https://smartmatatu-api.onrender.com/docs` to confirm it's live.

   Free-tier note: Render's free web services "sleep" after inactivity
   and take ~30-60 seconds to wake up on the next request. The first
   respondent after a quiet period will see a slow load — normal on the
   free tier, gone if you upgrade later.

## 3. Point the frontend at the real backend

Edit **`js/config.js`**:

```js
window.SmartMatatu.API_BASE_URL = "https://smartmatatu-api.onrender.com/api";
```

Commit and push this change.

## 4. Deploy the survey's static files

Only deploy the **public** files — not `admin/`:

- `index.html`, `survey.html`, `thank-you.html`
- `css/`
- `js/`

**Netlify (drag-and-drop, no build step needed):**
1. Copy those files/folders into a fresh folder, e.g. `public-site/`.
2. [app.netlify.com](https://app.netlify.com) → drag that folder onto
   the "Deploy manually" area.
3. Netlify gives you a URL like `https://smartmatatu.netlify.app` —
   that's your survey link.

**GitHub Pages, alternative:** works the same way, but since Pages
serves your whole repo, either use a separate branch/repo containing
only the public files, or accept that `admin/index.html` would also be
reachable at a guessable URL (see the privacy note below) — Netlify's
drag-and-drop is the simpler way to avoid that entirely.

## 5. Test it end-to-end before sharing the link

1. Open your Netlify survey URL, complete it once yourself.
2. Run the admin dashboard **locally** (see below) and confirm your test
   response shows up.
3. **Delete that test response** before real launch:
   ```bash
   cd backend
   python scripts/wipe_all_responses.py https://smartmatatu-api.onrender.com/api
   ```
   This lists everything and asks you to type `DELETE ALL` to confirm —
   it won't delete anything by accident. Point it at your live API URL
   (as shown), not the local default.

## 6. Share the link, watch it come in

Hand out the Netlify survey URL to real respondents. Every submission
now goes straight to your Postgres database on Render.

To check on responses, run the dashboard locally against the live
backend (it already points at the same `API_BASE_URL` from
`js/config.js`, since that file is shared):

```bash
python3 -m http.server 5500
# visit http://localhost:5500/admin/
```

---

## Keeping the dashboard private

`admin/` is not linked from any public page and isn't deployed to
Netlify in the steps above — that's what keeps it out of reach of
respondents. It is **not** protected by a login. If you ever do deploy
it somewhere reachable (even without a link to it, a URL can leak or be
guessed), add real authentication first — see the note in
`admin/README.md` for where that hook goes. Until then, the safest
setup is exactly what's above: run the dashboard only on your own
machine, pointed at the live backend.
